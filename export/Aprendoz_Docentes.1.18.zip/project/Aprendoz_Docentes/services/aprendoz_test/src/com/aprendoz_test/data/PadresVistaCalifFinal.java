
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaCalifFinal
 *  01/19/2015 07:58:53
 * 
 */
public class PadresVistaCalifFinal {

    private PadresVistaCalifFinalId id;

    public PadresVistaCalifFinalId getId() {
        return id;
    }

    public void setId(PadresVistaCalifFinalId id) {
        this.id = id;
    }

}
