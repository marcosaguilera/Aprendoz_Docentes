
package com.aprendoz_test.data.output;



/**
 * Generated for query "dash_aprendizajes" on 01/19/2015 07:59:26
 * 
 */
public class Dash_aprendizajesRtnType {

    private Integer idasignaturas;
    private String asignatura;
    private Long aprProgreso;
    private Long aprCompetente;
    private Long aprAvanzado;
    private Long aprMagistral;

    public Integer getIdasignaturas() {
        return idasignaturas;
    }

    public void setIdasignaturas(Integer idasignaturas) {
        this.idasignaturas = idasignaturas;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public Long getAprProgreso() {
        return aprProgreso;
    }

    public void setAprProgreso(Long aprProgreso) {
        this.aprProgreso = aprProgreso;
    }

    public Long getAprCompetente() {
        return aprCompetente;
    }

    public void setAprCompetente(Long aprCompetente) {
        this.aprCompetente = aprCompetente;
    }

    public Long getAprAvanzado() {
        return aprAvanzado;
    }

    public void setAprAvanzado(Long aprAvanzado) {
        this.aprAvanzado = aprAvanzado;
    }

    public Long getAprMagistral() {
        return aprMagistral;
    }

    public void setAprMagistral(Long aprMagistral) {
        this.aprMagistral = aprMagistral;
    }

}
