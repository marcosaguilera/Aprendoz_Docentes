
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAprendizajesAsignatura
 *  01/19/2015 07:58:52
 * 
 */
public class DocentesVistaAprendizajesAsignatura {

    private DocentesVistaAprendizajesAsignaturaId id;

    public DocentesVistaAprendizajesAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesVistaAprendizajesAsignaturaId id) {
        this.id = id;
    }

}
