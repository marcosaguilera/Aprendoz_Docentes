
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaPersonasDemografica
 *  01/19/2015 07:58:52
 * 
 */
public class DocentesVistaPersonasDemografica {

    private DocentesVistaPersonasDemograficaId id;

    public DocentesVistaPersonasDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

}
