
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaActividades
 *  01/19/2015 07:58:52
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}
