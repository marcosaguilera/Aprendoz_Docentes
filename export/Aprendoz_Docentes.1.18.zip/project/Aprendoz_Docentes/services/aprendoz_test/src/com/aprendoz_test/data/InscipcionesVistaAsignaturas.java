
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscipcionesVistaAsignaturas
 *  01/19/2015 07:58:52
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}
