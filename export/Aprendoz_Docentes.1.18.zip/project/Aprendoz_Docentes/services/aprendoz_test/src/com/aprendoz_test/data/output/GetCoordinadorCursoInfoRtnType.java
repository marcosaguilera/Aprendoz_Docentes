
package com.aprendoz_test.data.output;



/**
 * Generated for query "getCoordinadorCursoInfo" on 01/19/2015 07:59:25
 * 
 */
public class GetCoordinadorCursoInfoRtnType {

    private Integer idcurso;
    private String curso;
    private Integer idsy;
    private String sy;

    public Integer getIdcurso() {
        return idcurso;
    }

    public void setIdcurso(Integer idcurso) {
        this.idcurso = idcurso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public Integer getIdsy() {
        return idsy;
    }

    public void setIdsy(Integer idsy) {
        this.idsy = idsy;
    }

    public String getSy() {
        return sy;
    }

    public void setSy(String sy) {
        this.sy = sy;
    }

}
