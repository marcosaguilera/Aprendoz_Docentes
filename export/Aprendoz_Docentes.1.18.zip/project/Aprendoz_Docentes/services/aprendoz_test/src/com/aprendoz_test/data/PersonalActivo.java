
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PersonalActivo
 *  01/19/2015 07:58:53
 * 
 */
public class PersonalActivo {

    private PersonalActivoId id;

    public PersonalActivoId getId() {
        return id;
    }

    public void setId(PersonalActivoId id) {
        this.id = id;
    }

}
