
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TablaSaldosMatriculas
 *  01/19/2015 07:58:53
 * 
 */
public class TablaSaldosMatriculas {

    private TablaSaldosMatriculasId id;

    public TablaSaldosMatriculasId getId() {
        return id;
    }

    public void setId(TablaSaldosMatriculasId id) {
        this.id = id;
    }

}
