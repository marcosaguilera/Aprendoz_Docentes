
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CalifEstCopy
 *  01/19/2015 07:58:53
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
