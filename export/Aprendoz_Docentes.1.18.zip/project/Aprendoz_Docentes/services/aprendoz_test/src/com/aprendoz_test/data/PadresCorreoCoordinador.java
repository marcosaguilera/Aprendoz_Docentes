
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresCorreoCoordinador
 *  01/19/2015 07:58:52
 * 
 */
public class PadresCorreoCoordinador {

    private PadresCorreoCoordinadorId id;

    public PadresCorreoCoordinadorId getId() {
        return id;
    }

    public void setId(PadresCorreoCoordinadorId id) {
        this.id = id;
    }

}
