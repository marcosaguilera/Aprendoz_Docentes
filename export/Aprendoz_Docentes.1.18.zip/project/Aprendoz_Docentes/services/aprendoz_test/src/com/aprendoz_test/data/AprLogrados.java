
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AprLogrados
 *  01/19/2015 07:58:52
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
