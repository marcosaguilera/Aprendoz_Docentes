
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAsignaturaGrado
 *  01/19/2015 07:58:53
 * 
 */
public class DocentesVistaAsignaturaGrado {

    private DocentesVistaAsignaturaGradoId id;

    public DocentesVistaAsignaturaGradoId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturaGradoId id) {
        this.id = id;
    }

}
