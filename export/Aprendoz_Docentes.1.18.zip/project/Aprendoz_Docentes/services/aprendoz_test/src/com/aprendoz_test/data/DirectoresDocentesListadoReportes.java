
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DirectoresDocentesListadoReportes
 *  01/19/2015 07:58:53
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}
