
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaPersonas
 *  01/19/2015 07:58:52
 * 
 */
public class AdministracionVistaPersonas {

    private AdministracionVistaPersonasId id;

    public AdministracionVistaPersonasId getId() {
        return id;
    }

    public void setId(AdministracionVistaPersonasId id) {
        this.id = id;
    }

}
