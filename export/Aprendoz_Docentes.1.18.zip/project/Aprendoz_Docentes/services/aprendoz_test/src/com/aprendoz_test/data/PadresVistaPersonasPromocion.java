
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaPersonasPromocion
 *  01/19/2015 07:58:53
 * 
 */
public class PadresVistaPersonasPromocion {

    private PadresVistaPersonasPromocionId id;

    public PadresVistaPersonasPromocionId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasPromocionId id) {
        this.id = id;
    }

}
