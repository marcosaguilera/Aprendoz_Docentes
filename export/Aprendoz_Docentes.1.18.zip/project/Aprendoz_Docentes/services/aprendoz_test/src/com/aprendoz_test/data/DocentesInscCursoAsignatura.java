
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesInscCursoAsignatura
 *  01/19/2015 07:58:53
 * 
 */
public class DocentesInscCursoAsignatura {

    private DocentesInscCursoAsignaturaId id;

    public DocentesInscCursoAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

}
