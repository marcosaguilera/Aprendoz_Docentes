
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaRecursos
 *  01/19/2015 07:58:53
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
