
package com.aprendoz_test.data;



/**
 *  aprendoz_test.Anticipos
 *  01/19/2015 07:58:53
 * 
 */
public class Anticipos {

    private Integer idAnticipos;
    private String codigo;

    public Integer getIdAnticipos() {
        return idAnticipos;
    }

    public void setIdAnticipos(Integer idAnticipos) {
        this.idAnticipos = idAnticipos;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

}
