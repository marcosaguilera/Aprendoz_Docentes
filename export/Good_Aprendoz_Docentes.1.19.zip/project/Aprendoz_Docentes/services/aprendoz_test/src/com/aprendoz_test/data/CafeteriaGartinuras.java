
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CafeteriaGartinuras
 *  01/19/2015 07:58:52
 * 
 */
public class CafeteriaGartinuras {

    private Integer idGarnituras;
    private String garnitura;
    private String descripcion;
    private String imageLink;

    public Integer getIdGarnituras() {
        return idGarnituras;
    }

    public void setIdGarnituras(Integer idGarnituras) {
        this.idGarnituras = idGarnituras;
    }

    public String getGarnitura() {
        return garnitura;
    }

    public void setGarnitura(String garnitura) {
        this.garnitura = garnitura;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public String getImageLink() {
        return imageLink;
    }

    public void setImageLink(String imageLink) {
        this.imageLink = imageLink;
    }

}
