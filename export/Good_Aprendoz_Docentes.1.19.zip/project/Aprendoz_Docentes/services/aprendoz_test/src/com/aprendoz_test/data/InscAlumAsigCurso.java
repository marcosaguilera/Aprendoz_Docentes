
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscAlumAsigCurso
 *  01/19/2015 07:58:53
 * 
 */
public class InscAlumAsigCurso {

    private InscAlumAsigCursoId id;

    public InscAlumAsigCursoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoId id) {
        this.id = id;
    }

}
