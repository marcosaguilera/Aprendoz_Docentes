
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TablaAnticiposMatriculas
 *  01/19/2015 07:58:53
 * 
 */
public class TablaAnticiposMatriculas {

    private TablaAnticiposMatriculasId id;

    public TablaAnticiposMatriculasId getId() {
        return id;
    }

    public void setId(TablaAnticiposMatriculasId id) {
        this.id = id;
    }

}
