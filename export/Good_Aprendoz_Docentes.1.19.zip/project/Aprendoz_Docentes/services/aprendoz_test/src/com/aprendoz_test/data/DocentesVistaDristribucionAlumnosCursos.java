
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaDristribucionAlumnosCursos
 *  01/19/2015 07:58:53
 * 
 */
public class DocentesVistaDristribucionAlumnosCursos {

    private DocentesVistaDristribucionAlumnosCursosId id;

    public DocentesVistaDristribucionAlumnosCursosId getId() {
        return id;
    }

    public void setId(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

}
