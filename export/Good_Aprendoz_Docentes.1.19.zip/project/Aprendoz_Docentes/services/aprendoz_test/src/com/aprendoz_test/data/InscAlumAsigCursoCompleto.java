
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscAlumAsigCursoCompleto
 *  01/19/2015 07:58:52
 * 
 */
public class InscAlumAsigCursoCompleto {

    private InscAlumAsigCursoCompletoId id;

    public InscAlumAsigCursoCompletoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoCompletoId id) {
        this.id = id;
    }

}
