
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CalifEstCopy
 *  01/13/2015 09:58:57
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
