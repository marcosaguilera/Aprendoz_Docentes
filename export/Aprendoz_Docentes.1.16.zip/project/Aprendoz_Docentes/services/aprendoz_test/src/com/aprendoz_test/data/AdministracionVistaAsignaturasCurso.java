
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaAsignaturasCurso
 *  01/13/2015 09:58:57
 * 
 */
public class AdministracionVistaAsignaturasCurso {

    private AdministracionVistaAsignaturasCursoId id;

    public AdministracionVistaAsignaturasCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasCursoId id) {
        this.id = id;
    }

}
