
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesInscCursoAsignatura
 *  01/13/2015 09:58:58
 * 
 */
public class DocentesInscCursoAsignatura {

    private DocentesInscCursoAsignaturaId id;

    public DocentesInscCursoAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

}
