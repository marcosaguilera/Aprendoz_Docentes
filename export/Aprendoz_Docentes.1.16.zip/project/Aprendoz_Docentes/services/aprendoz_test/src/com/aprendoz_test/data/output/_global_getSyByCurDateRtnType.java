
package com.aprendoz_test.data.output;

import java.util.Date;


/**
 * Generated for query "_global_getSyByCurDate" on 01/13/2015 09:59:27
 * 
 */
public class _global_getSyByCurDateRtnType {

    private Integer idsy;
    private String sy;
    private Date fechaDesde;
    private Date fechaHasta;

    public Integer getIdsy() {
        return idsy;
    }

    public void setIdsy(Integer idsy) {
        this.idsy = idsy;
    }

    public String getSy() {
        return sy;
    }

    public void setSy(String sy) {
        this.sy = sy;
    }

    public Date getFechaDesde() {
        return fechaDesde;
    }

    public void setFechaDesde(Date fechaDesde) {
        this.fechaDesde = fechaDesde;
    }

    public Date getFechaHasta() {
        return fechaHasta;
    }

    public void setFechaHasta(Date fechaHasta) {
        this.fechaHasta = fechaHasta;
    }

}
