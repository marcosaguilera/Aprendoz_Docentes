
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaInscAlumnAsigDemografica
 *  01/13/2015 09:58:57
 * 
 */
public class DocentesVistaInscAlumnAsigDemografica {

    private DocentesVistaInscAlumnAsigDemograficaId id;

    public DocentesVistaInscAlumnAsigDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigDemograficaId id) {
        this.id = id;
    }

}
