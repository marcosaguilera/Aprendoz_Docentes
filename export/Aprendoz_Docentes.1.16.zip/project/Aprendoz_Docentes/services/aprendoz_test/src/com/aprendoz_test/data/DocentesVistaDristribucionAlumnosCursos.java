
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaDristribucionAlumnosCursos
 *  01/13/2015 09:58:58
 * 
 */
public class DocentesVistaDristribucionAlumnosCursos {

    private DocentesVistaDristribucionAlumnosCursosId id;

    public DocentesVistaDristribucionAlumnosCursosId getId() {
        return id;
    }

    public void setId(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

}
