
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresCorreosPadres
 *  01/13/2015 09:58:57
 * 
 */
public class PadresCorreosPadres {

    private PadresCorreosPadresId id;

    public PadresCorreosPadresId getId() {
        return id;
    }

    public void setId(PadresCorreosPadresId id) {
        this.id = id;
    }

}
