
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaPersonas
 *  01/13/2015 09:58:57
 * 
 */
public class AdministracionVistaPersonas {

    private AdministracionVistaPersonasId id;

    public AdministracionVistaPersonasId getId() {
        return id;
    }

    public void setId(AdministracionVistaPersonasId id) {
        this.id = id;
    }

}
