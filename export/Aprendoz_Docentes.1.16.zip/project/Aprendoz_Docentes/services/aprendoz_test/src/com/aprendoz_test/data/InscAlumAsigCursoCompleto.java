
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscAlumAsigCursoCompleto
 *  01/13/2015 09:58:56
 * 
 */
public class InscAlumAsigCursoCompleto {

    private InscAlumAsigCursoCompletoId id;

    public InscAlumAsigCursoCompletoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoCompletoId id) {
        this.id = id;
    }

}
