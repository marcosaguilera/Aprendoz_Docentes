
package com.aprendoz_test.data.output;



/**
 * Generated for query "HQLlsCursos" on 01/13/2015 09:59:27
 * 
 */
public class HQLlsCursosRtnType {

    private Integer id;
    private String curso;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

}
