
package com.aprendoz_test.data.output;

import java.util.Date;


/**
 * Generated for query "estudiantes_listado_curriculo" on 01/13/2015 09:59:27
 * 
 */
public class Estudiantes_listado_curriculoRtnType {

    private Integer idasignatura;
    private Integer idpersona;
    private Integer idunidad;
    private String unidad;
    private Integer numerounidad;
    private Integer idsubtopico;
    private String subtopico;
    private Integer numerosubtopico;
    private Integer idaprendizaje;
    private String aprendizaje;
    private Date fechaesperada;
    private Integer peso;

    public Integer getIdasignatura() {
        return idasignatura;
    }

    public void setIdasignatura(Integer idasignatura) {
        this.idasignatura = idasignatura;
    }

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public Integer getIdunidad() {
        return idunidad;
    }

    public void setIdunidad(Integer idunidad) {
        this.idunidad = idunidad;
    }

    public String getUnidad() {
        return unidad;
    }

    public void setUnidad(String unidad) {
        this.unidad = unidad;
    }

    public Integer getNumerounidad() {
        return numerounidad;
    }

    public void setNumerounidad(Integer numerounidad) {
        this.numerounidad = numerounidad;
    }

    public Integer getIdsubtopico() {
        return idsubtopico;
    }

    public void setIdsubtopico(Integer idsubtopico) {
        this.idsubtopico = idsubtopico;
    }

    public String getSubtopico() {
        return subtopico;
    }

    public void setSubtopico(String subtopico) {
        this.subtopico = subtopico;
    }

    public Integer getNumerosubtopico() {
        return numerosubtopico;
    }

    public void setNumerosubtopico(Integer numerosubtopico) {
        this.numerosubtopico = numerosubtopico;
    }

    public Integer getIdaprendizaje() {
        return idaprendizaje;
    }

    public void setIdaprendizaje(Integer idaprendizaje) {
        this.idaprendizaje = idaprendizaje;
    }

    public String getAprendizaje() {
        return aprendizaje;
    }

    public void setAprendizaje(String aprendizaje) {
        this.aprendizaje = aprendizaje;
    }

    public Date getFechaesperada() {
        return fechaesperada;
    }

    public void setFechaesperada(Date fechaesperada) {
        this.fechaesperada = fechaesperada;
    }

    public Integer getPeso() {
        return peso;
    }

    public void setPeso(Integer peso) {
        this.peso = peso;
    }

}
