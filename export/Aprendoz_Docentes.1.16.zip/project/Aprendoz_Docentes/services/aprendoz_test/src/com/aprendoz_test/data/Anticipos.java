
package com.aprendoz_test.data;



/**
 *  aprendoz_test.Anticipos
 *  01/13/2015 09:58:57
 * 
 */
public class Anticipos {

    private Integer idAnticipos;
    private String codigo;

    public Integer getIdAnticipos() {
        return idAnticipos;
    }

    public void setIdAnticipos(Integer idAnticipos) {
        this.idAnticipos = idAnticipos;
    }

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

}
