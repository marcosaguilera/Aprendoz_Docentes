
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PersonaEdad
 *  01/13/2015 09:58:57
 * 
 */
public class PersonaEdad {

    private PersonaEdadId id;

    public PersonaEdadId getId() {
        return id;
    }

    public void setId(PersonaEdadId id) {
        this.id = id;
    }

}
