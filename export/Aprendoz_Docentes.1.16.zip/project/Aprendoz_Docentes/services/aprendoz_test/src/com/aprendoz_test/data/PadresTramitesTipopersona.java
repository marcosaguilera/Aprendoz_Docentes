
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresTramitesTipopersona
 *  01/13/2015 09:58:58
 * 
 */
public class PadresTramitesTipopersona {

    private PadresTramitesTipopersonaId id;

    public PadresTramitesTipopersonaId getId() {
        return id;
    }

    public void setId(PadresTramitesTipopersonaId id) {
        this.id = id;
    }

}
