
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscipcionesVistaAsignaturas
 *  01/13/2015 09:58:57
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}
