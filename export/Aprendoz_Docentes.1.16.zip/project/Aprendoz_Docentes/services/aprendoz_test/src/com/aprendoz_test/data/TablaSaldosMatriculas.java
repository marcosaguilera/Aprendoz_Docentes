
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TablaSaldosMatriculas
 *  01/13/2015 09:58:57
 * 
 */
public class TablaSaldosMatriculas {

    private TablaSaldosMatriculasId id;

    public TablaSaldosMatriculasId getId() {
        return id;
    }

    public void setId(TablaSaldosMatriculasId id) {
        this.id = id;
    }

}
