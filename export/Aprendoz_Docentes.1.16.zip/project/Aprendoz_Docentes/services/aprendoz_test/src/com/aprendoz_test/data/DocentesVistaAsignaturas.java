
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAsignaturas
 *  01/13/2015 09:58:58
 * 
 */
public class DocentesVistaAsignaturas {

    private DocentesVistaAsignaturasId id;

    public DocentesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturasId id) {
        this.id = id;
    }

}
