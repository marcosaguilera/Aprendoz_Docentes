
package com.aprendoz_test.data;



/**
 *  aprendoz_test.Meses
 *  01/13/2015 09:58:57
 * 
 */
public class Meses {

    private Integer id;
    private String mes;
    private String mesnumero;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public String getMesnumero() {
        return mesnumero;
    }

    public void setMesnumero(String mesnumero) {
        this.mesnumero = mesnumero;
    }

}
