
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DirectoresDocentesListadoReportes
 *  01/13/2015 09:58:57
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}
