
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaPersonas
 *  01/13/2015 09:58:58
 * 
 */
public class PadresVistaPersonas {

    private PadresVistaPersonasId id;

    public PadresVistaPersonasId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasId id) {
        this.id = id;
    }

}
