
package com.aprendoz_test.data;



/**
 *  aprendoz_test.BisUsers
 *  01/13/2015 09:58:57
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}
