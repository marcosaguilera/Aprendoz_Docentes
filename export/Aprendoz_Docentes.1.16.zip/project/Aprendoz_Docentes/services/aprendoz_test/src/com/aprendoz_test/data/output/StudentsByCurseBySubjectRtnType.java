
package com.aprendoz_test.data.output;



/**
 * Generated for query "studentsByCurseBySubject" on 01/13/2015 09:59:27
 * 
 */
public class StudentsByCurseBySubjectRtnType {

    private String codigo;
    private Integer idpersona;
    private Integer idasignatura;
    private String asignatura;
    private String nombres;
    private String apellidos;
    private Integer idpersona2;
    private Integer idpersonacurso;
    private String curso;
    private Integer idaa;

    public String getCodigo() {
        return codigo;
    }

    public void setCodigo(String codigo) {
        this.codigo = codigo;
    }

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public Integer getIdasignatura() {
        return idasignatura;
    }

    public void setIdasignatura(Integer idasignatura) {
        this.idasignatura = idasignatura;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getApellidos() {
        return apellidos;
    }

    public void setApellidos(String apellidos) {
        this.apellidos = apellidos;
    }

    public Integer getIdpersona2() {
        return idpersona2;
    }

    public void setIdpersona2(Integer idpersona2) {
        this.idpersona2 = idpersona2;
    }

    public Integer getIdpersonacurso() {
        return idpersonacurso;
    }

    public void setIdpersonacurso(Integer idpersonacurso) {
        this.idpersonacurso = idpersonacurso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public Integer getIdaa() {
        return idaa;
    }

    public void setIdaa(Integer idaa) {
        this.idaa = idaa;
    }

}
