
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresCorreoCoordinador
 *  01/13/2015 09:58:56
 * 
 */
public class PadresCorreoCoordinador {

    private PadresCorreoCoordinadorId id;

    public PadresCorreoCoordinadorId getId() {
        return id;
    }

    public void setId(PadresCorreoCoordinadorId id) {
        this.id = id;
    }

}
