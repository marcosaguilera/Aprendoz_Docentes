
package com.aprendoz_test.data;



/**
 *  aprendoz_test.Anuncio
 *  01/13/2015 09:58:57
 * 
 */
public class Anuncio {

    private String anuncio;

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
