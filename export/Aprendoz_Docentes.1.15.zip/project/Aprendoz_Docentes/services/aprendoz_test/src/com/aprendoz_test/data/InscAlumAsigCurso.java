
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscAlumAsigCurso
 *  01/13/2015 09:58:57
 * 
 */
public class InscAlumAsigCurso {

    private InscAlumAsigCursoId id;

    public InscAlumAsigCursoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoId id) {
        this.id = id;
    }

}
