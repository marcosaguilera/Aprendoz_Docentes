
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesAsistenciaAsistencias
 *  01/13/2015 09:58:57
 * 
 */
public class DocentesAsistenciaAsistencias {

    private DocentesAsistenciaAsistenciasId id;

    public DocentesAsistenciaAsistenciasId getId() {
        return id;
    }

    public void setId(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

}
