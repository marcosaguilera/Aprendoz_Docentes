
package com.aprendoz_test.data.output;



/**
 * Generated for query "hQLlsGrado" on 01/13/2015 09:59:27
 * 
 */
public class HQLlsGradoRtnType {

    private Integer id;
    private String grado;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

}
