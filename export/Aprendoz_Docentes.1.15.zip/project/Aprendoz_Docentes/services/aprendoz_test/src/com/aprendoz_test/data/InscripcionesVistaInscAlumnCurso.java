
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscripcionesVistaInscAlumnCurso
 *  01/13/2015 09:58:57
 * 
 */
public class InscripcionesVistaInscAlumnCurso {

    private InscripcionesVistaInscAlumnCursoId id;

    public InscripcionesVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(InscripcionesVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
