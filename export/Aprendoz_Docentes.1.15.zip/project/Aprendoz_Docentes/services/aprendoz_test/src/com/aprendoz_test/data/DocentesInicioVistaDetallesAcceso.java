
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesInicioVistaDetallesAcceso
 *  01/13/2015 09:58:57
 * 
 */
public class DocentesInicioVistaDetallesAcceso {

    private DocentesInicioVistaDetallesAccesoId id;

    public DocentesInicioVistaDetallesAccesoId getId() {
        return id;
    }

    public void setId(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

}
