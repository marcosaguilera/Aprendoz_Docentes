
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PromocionVistaInscAlumnCurso
 *  01/13/2015 09:58:57
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
