
package com.aprendoz_test.data.output;



/**
 * Generated for query "getScheduleByProfile" on 01/13/2015 09:59:27
 * 
 */
public class GetScheduleByProfileRtnType {

    private Integer id;
    private Integer numero_sesion;
    private String dia;
    private Integer idsy;
    private String sy_schoolar;
    private Integer idasignatura;
    private String asignatura;
    private Integer idcurso;
    private String curso;
    private Integer idsemana;
    private String tiposemana;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getNumero_sesion() {
        return numero_sesion;
    }

    public void setNumero_sesion(Integer numero_sesion) {
        this.numero_sesion = numero_sesion;
    }

    public String getDia() {
        return dia;
    }

    public void setDia(String dia) {
        this.dia = dia;
    }

    public Integer getIdsy() {
        return idsy;
    }

    public void setIdsy(Integer idsy) {
        this.idsy = idsy;
    }

    public String getSy_schoolar() {
        return sy_schoolar;
    }

    public void setSy_schoolar(String sy_schoolar) {
        this.sy_schoolar = sy_schoolar;
    }

    public Integer getIdasignatura() {
        return idasignatura;
    }

    public void setIdasignatura(Integer idasignatura) {
        this.idasignatura = idasignatura;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public Integer getIdcurso() {
        return idcurso;
    }

    public void setIdcurso(Integer idcurso) {
        this.idcurso = idcurso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public Integer getIdsemana() {
        return idsemana;
    }

    public void setIdsemana(Integer idsemana) {
        this.idsemana = idsemana;
    }

    public String getTiposemana() {
        return tiposemana;
    }

    public void setTiposemana(String tiposemana) {
        this.tiposemana = tiposemana;
    }

}
