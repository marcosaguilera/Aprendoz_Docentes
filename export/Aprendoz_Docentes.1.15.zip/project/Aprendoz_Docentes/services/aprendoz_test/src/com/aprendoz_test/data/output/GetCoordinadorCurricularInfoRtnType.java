
package com.aprendoz_test.data.output;



/**
 * Generated for query "getCoordinadorCurricularInfo" on 01/13/2015 09:59:27
 * 
 */
public class GetCoordinadorCurricularInfoRtnType {

    private Integer idsy;
    private Integer idPersona;

    public Integer getIdsy() {
        return idsy;
    }

    public void setIdsy(Integer idsy) {
        this.idsy = idsy;
    }

    public Integer getIdPersona() {
        return idPersona;
    }

    public void setIdPersona(Integer idPersona) {
        this.idPersona = idPersona;
    }

}
