
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaInscAlumAsig
 *  01/13/2015 09:58:57
 * 
 */
public class AdministracionVistaInscAlumAsig {

    private AdministracionVistaInscAlumAsigId id;

    public AdministracionVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumAsigId id) {
        this.id = id;
    }

}
