
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaRecursos
 *  01/13/2015 09:58:57
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
