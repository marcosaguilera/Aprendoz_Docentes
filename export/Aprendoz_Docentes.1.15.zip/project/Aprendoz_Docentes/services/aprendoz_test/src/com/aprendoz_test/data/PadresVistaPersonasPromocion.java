
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaPersonasPromocion
 *  01/13/2015 09:58:56
 * 
 */
public class PadresVistaPersonasPromocion {

    private PadresVistaPersonasPromocionId id;

    public PadresVistaPersonasPromocionId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasPromocionId id) {
        this.id = id;
    }

}
