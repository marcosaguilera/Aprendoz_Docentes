
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AprLogrados
 *  01/13/2015 09:58:57
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
