
package com.aprendoz_test.data;



/**
 *  aprendoz_test.FacturacionSapiens
 *  01/13/2015 09:58:56
 * 
 */
public class FacturacionSapiens {

    private FacturacionSapiensId id;

    public FacturacionSapiensId getId() {
        return id;
    }

    public void setId(FacturacionSapiensId id) {
        this.id = id;
    }

}
