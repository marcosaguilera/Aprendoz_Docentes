
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaInscAlumnCurso
 *  01/13/2015 09:58:57
 * 
 */
public class AdministracionVistaInscAlumnCurso {

    private AdministracionVistaInscAlumnCursoId id;

    public AdministracionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
