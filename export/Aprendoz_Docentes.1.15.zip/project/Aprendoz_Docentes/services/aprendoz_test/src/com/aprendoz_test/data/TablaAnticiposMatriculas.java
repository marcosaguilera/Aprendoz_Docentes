
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TablaAnticiposMatriculas
 *  01/13/2015 09:58:57
 * 
 */
public class TablaAnticiposMatriculas {

    private TablaAnticiposMatriculasId id;

    public TablaAnticiposMatriculasId getId() {
        return id;
    }

    public void setId(TablaAnticiposMatriculasId id) {
        this.id = id;
    }

}
