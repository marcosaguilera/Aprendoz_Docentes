
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAprendizajesAsignatura
 *  01/13/2015 09:58:56
 * 
 */
public class DocentesVistaAprendizajesAsignatura {

    private DocentesVistaAprendizajesAsignaturaId id;

    public DocentesVistaAprendizajesAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesVistaAprendizajesAsignaturaId id) {
        this.id = id;
    }

}
