
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AprEsperados
 *  01/13/2015 09:58:56
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
