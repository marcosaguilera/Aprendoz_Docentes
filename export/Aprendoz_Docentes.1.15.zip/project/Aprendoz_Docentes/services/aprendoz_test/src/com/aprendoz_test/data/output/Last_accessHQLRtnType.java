
package com.aprendoz_test.data.output;

import java.util.Date;


/**
 * Generated for query "last_accessHQL" on 01/13/2015 09:59:27
 * 
 */
public class Last_accessHQLRtnType {

    private String date;
    private Date timeLoged;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Date getTimeLoged() {
        return timeLoged;
    }

    public void setTimeLoged(Date timeLoged) {
        this.timeLoged = timeLoged;
    }

}
