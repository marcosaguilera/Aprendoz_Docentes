
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaActividades
 *  01/13/2015 09:58:57
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}
