
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaCalificacionFinal
 *  01/13/2015 09:58:57
 * 
 */
public class DocentesVistaCalificacionFinal {

    private DocentesVistaCalificacionFinalId id;

    public DocentesVistaCalificacionFinalId getId() {
        return id;
    }

    public void setId(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

}
