
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesInscCursoAsignatura
 *  07/31/2014 10:31:31
 * 
 */
public class DocentesInscCursoAsignatura {

    private DocentesInscCursoAsignaturaId id;

    public DocentesInscCursoAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

}
