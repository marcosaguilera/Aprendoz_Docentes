
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaInscAlumAsig
 *  07/31/2014 10:31:31
 * 
 */
public class PadresVistaInscAlumAsig {

    private PadresVistaInscAlumAsigId id;

    public PadresVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

}
