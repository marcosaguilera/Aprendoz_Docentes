
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaCalificacionFinal
 *  07/31/2014 10:31:31
 * 
 */
public class DocentesVistaCalificacionFinal {

    private DocentesVistaCalificacionFinalId id;

    public DocentesVistaCalificacionFinalId getId() {
        return id;
    }

    public void setId(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

}
