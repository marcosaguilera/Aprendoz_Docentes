
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PersonaEdad
 *  07/31/2014 10:31:31
 * 
 */
public class PersonaEdad {

    private PersonaEdadId id;

    public PersonaEdadId getId() {
        return id;
    }

    public void setId(PersonaEdadId id) {
        this.id = id;
    }

}
