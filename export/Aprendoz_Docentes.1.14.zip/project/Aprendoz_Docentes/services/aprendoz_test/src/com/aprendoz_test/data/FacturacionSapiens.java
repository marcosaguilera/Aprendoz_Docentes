
package com.aprendoz_test.data;



/**
 *  aprendoz_test.FacturacionSapiens
 *  07/31/2014 10:31:31
 * 
 */
public class FacturacionSapiens {

    private FacturacionSapiensId id;

    public FacturacionSapiensId getId() {
        return id;
    }

    public void setId(FacturacionSapiensId id) {
        this.id = id;
    }

}
