
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AprEsperados
 *  07/31/2014 10:31:31
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
