
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TablaSaldosMatriculas
 *  07/31/2014 10:31:32
 * 
 */
public class TablaSaldosMatriculas {

    private TablaSaldosMatriculasId id;

    public TablaSaldosMatriculasId getId() {
        return id;
    }

    public void setId(TablaSaldosMatriculasId id) {
        this.id = id;
    }

}
