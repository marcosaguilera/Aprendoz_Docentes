
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PromocionVistaInscAlumnCurso
 *  07/31/2014 10:31:31
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
