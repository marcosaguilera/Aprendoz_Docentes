
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TablaAnticiposMatriculas
 *  07/31/2014 10:31:31
 * 
 */
public class TablaAnticiposMatriculas {

    private TablaAnticiposMatriculasId id;

    public TablaAnticiposMatriculasId getId() {
        return id;
    }

    public void setId(TablaAnticiposMatriculasId id) {
        this.id = id;
    }

}
