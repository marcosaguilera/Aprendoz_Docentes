
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAprendizajesAsignatura
 *  07/31/2014 10:31:31
 * 
 */
public class DocentesVistaAprendizajesAsignatura {

    private DocentesVistaAprendizajesAsignaturaId id;

    public DocentesVistaAprendizajesAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesVistaAprendizajesAsignaturaId id) {
        this.id = id;
    }

}
