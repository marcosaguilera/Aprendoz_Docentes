
package com.aprendoz_test.data.output;



/**
 * Generated for query "hQLlsGrado" on 07/31/2014 10:31:51
 * 
 */
public class HQLlsGradoRtnType {

    private Integer id;
    private String grado;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

}
