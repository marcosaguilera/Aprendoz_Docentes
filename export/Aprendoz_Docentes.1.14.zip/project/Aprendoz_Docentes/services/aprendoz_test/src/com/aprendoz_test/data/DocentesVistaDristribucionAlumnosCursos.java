
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaDristribucionAlumnosCursos
 *  07/31/2014 10:31:32
 * 
 */
public class DocentesVistaDristribucionAlumnosCursos {

    private DocentesVistaDristribucionAlumnosCursosId id;

    public DocentesVistaDristribucionAlumnosCursosId getId() {
        return id;
    }

    public void setId(DocentesVistaDristribucionAlumnosCursosId id) {
        this.id = id;
    }

}
