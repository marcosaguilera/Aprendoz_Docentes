
package com.aprendoz_test.data.output;



/**
 * Generated for query "HQLlsPeriodo" on 07/31/2014 10:31:50
 * 
 */
public class HQLlsPeriodoRtnType {

    private Integer id;
    private String periodo;
    private String tipoP;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public String getTipoP() {
        return tipoP;
    }

    public void setTipoP(String tipoP) {
        this.tipoP = tipoP;
    }

}
