
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CalifEstCopy
 *  07/31/2014 10:31:32
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
