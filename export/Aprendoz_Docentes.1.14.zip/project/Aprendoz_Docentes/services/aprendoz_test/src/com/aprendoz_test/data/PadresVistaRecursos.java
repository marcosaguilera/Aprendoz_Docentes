
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaRecursos
 *  07/31/2014 10:31:31
 * 
 */
public class PadresVistaRecursos {

    private PadresVistaRecursosId id;

    public PadresVistaRecursosId getId() {
        return id;
    }

    public void setId(PadresVistaRecursosId id) {
        this.id = id;
    }

}
