
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AprLogrados
 *  07/31/2014 10:31:31
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
