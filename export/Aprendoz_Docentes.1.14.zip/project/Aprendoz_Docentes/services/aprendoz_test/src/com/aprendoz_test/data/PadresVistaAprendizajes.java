
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaAprendizajes
 *  07/31/2014 10:31:31
 * 
 */
public class PadresVistaAprendizajes {

    private PadresVistaAprendizajesId id;

    public PadresVistaAprendizajesId getId() {
        return id;
    }

    public void setId(PadresVistaAprendizajesId id) {
        this.id = id;
    }

}
