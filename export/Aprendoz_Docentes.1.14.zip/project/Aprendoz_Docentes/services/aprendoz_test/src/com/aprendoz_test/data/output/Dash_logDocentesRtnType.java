
package com.aprendoz_test.data.output;



/**
 * Generated for query "dash_logDocentes" on 07/31/2014 10:31:51
 * 
 */
public class Dash_logDocentesRtnType {

    private String usuario;
    private String mes;
    private Long totalingresos;
    private Integer sy;

    public String getUsuario() {
        return usuario;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public Long getTotalingresos() {
        return totalingresos;
    }

    public void setTotalingresos(Long totalingresos) {
        this.totalingresos = totalingresos;
    }

    public Integer getSy() {
        return sy;
    }

    public void setSy(Integer sy) {
        this.sy = sy;
    }

}
