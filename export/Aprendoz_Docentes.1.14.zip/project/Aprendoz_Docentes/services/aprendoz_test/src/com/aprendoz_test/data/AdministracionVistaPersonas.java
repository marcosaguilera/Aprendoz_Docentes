
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaPersonas
 *  07/31/2014 10:31:31
 * 
 */
public class AdministracionVistaPersonas {

    private AdministracionVistaPersonasId id;

    public AdministracionVistaPersonasId getId() {
        return id;
    }

    public void setId(AdministracionVistaPersonasId id) {
        this.id = id;
    }

}
