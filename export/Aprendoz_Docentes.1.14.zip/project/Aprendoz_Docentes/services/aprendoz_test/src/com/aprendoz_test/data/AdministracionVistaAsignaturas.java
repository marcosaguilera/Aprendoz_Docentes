
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaAsignaturas
 *  07/31/2014 10:31:31
 * 
 */
public class AdministracionVistaAsignaturas {

    private AdministracionVistaAsignaturasId id;

    public AdministracionVistaAsignaturasId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasId id) {
        this.id = id;
    }

}
