
package com.aprendoz_test.data;



/**
 *  aprendoz_test.ImportacionExtracto
 *  07/31/2014 10:31:31
 * 
 */
public class ImportacionExtracto {

    private ImportacionExtractoId id;

    public ImportacionExtractoId getId() {
        return id;
    }

    public void setId(ImportacionExtractoId id) {
        this.id = id;
    }

}
