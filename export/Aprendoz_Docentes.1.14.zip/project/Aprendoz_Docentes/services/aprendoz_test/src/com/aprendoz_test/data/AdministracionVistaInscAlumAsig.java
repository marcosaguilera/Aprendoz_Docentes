
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaInscAlumAsig
 *  07/31/2014 10:31:31
 * 
 */
public class AdministracionVistaInscAlumAsig {

    private AdministracionVistaInscAlumAsigId id;

    public AdministracionVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumAsigId id) {
        this.id = id;
    }

}
