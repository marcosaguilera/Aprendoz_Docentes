
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaPersonas
 *  07/31/2014 10:31:31
 * 
 */
public class PadresVistaPersonas {

    private PadresVistaPersonasId id;

    public PadresVistaPersonasId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasId id) {
        this.id = id;
    }

}
