
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaInscAlumnCurso
 *  07/31/2014 10:31:31
 * 
 */
public class AdministracionVistaInscAlumnCurso {

    private AdministracionVistaInscAlumnCursoId id;

    public AdministracionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
