
package com.aprendoz_test.data;



/**
 *  aprendoz_test.ServiciosListadoServiciosAlumnos
 *  07/31/2014 10:31:31
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}
