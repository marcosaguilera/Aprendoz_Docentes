
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscripcionesVistaInscAlumnCurso
 *  07/31/2014 10:31:31
 * 
 */
public class InscripcionesVistaInscAlumnCurso {

    private InscripcionesVistaInscAlumnCursoId id;

    public InscripcionesVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(InscripcionesVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
