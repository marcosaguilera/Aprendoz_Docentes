
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaAsignaturasCurso
 *  07/31/2014 10:31:32
 * 
 */
public class AdministracionVistaAsignaturasCurso {

    private AdministracionVistaAsignaturasCursoId id;

    public AdministracionVistaAsignaturasCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasCursoId id) {
        this.id = id;
    }

}
