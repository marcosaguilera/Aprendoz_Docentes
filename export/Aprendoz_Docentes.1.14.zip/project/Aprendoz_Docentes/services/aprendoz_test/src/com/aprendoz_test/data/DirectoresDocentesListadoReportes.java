
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DirectoresDocentesListadoReportes
 *  07/31/2014 10:31:31
 * 
 */
public class DirectoresDocentesListadoReportes {

    private DirectoresDocentesListadoReportesId id;

    public DirectoresDocentesListadoReportesId getId() {
        return id;
    }

    public void setId(DirectoresDocentesListadoReportesId id) {
        this.id = id;
    }

}
