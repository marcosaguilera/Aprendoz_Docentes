
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CalifEst
 *  07/31/2014 10:31:31
 * 
 */
public class CalifEst {

    private CalifEstId id;

    public CalifEstId getId() {
        return id;
    }

    public void setId(CalifEstId id) {
        this.id = id;
    }

}
