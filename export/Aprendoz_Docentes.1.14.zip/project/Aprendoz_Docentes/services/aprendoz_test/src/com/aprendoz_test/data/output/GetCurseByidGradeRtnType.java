
package com.aprendoz_test.data.output;



/**
 * Generated for query "getCurseByidGrade" on 07/31/2014 10:31:51
 * 
 */
public class GetCurseByidGradeRtnType {

    private Integer idcurso;
    private String curso;
    private Integer idgrado;
    private String grado;

    public Integer getIdcurso() {
        return idcurso;
    }

    public void setIdcurso(Integer idcurso) {
        this.idcurso = idcurso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public Integer getIdgrado() {
        return idgrado;
    }

    public void setIdgrado(Integer idgrado) {
        this.idgrado = idgrado;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

}
