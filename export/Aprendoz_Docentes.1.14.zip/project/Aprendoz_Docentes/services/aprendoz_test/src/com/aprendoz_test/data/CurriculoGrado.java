
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CurriculoGrado
 *  07/31/2014 10:31:31
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}
