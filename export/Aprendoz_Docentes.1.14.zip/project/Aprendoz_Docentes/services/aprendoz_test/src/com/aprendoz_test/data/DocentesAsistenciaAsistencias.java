
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesAsistenciaAsistencias
 *  07/31/2014 10:31:32
 * 
 */
public class DocentesAsistenciaAsistencias {

    private DocentesAsistenciaAsistenciasId id;

    public DocentesAsistenciaAsistenciasId getId() {
        return id;
    }

    public void setId(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

}
