
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAsignaturas
 *  07/31/2014 10:31:31
 * 
 */
public class DocentesVistaAsignaturas {

    private DocentesVistaAsignaturasId id;

    public DocentesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturasId id) {
        this.id = id;
    }

}
