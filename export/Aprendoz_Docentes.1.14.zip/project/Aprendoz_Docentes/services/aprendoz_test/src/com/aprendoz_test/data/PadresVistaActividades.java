
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaActividades
 *  07/31/2014 10:31:31
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}
