
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscAlumAsigCursoCompleto
 *  07/31/2014 10:31:31
 * 
 */
public class InscAlumAsigCursoCompleto {

    private InscAlumAsigCursoCompletoId id;

    public InscAlumAsigCursoCompletoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoCompletoId id) {
        this.id = id;
    }

}
