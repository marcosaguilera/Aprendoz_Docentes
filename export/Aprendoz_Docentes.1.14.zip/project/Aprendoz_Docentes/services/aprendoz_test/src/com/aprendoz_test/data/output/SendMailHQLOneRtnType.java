
package com.aprendoz_test.data.output;

import java.util.Date;


/**
 * Generated for query "sendMailHQLOne" on 07/31/2014 10:31:50
 * 
 */
public class SendMailHQLOneRtnType {

    private Integer idalumno;
    private String nombreAlumno;
    private Integer ide;
    private String registrante;
    private String curso;
    private String cor_user;
    private String cor_mail;
    private Date fecha;
    private Date hora;
    private String lugar;
    private String tipo;
    private String subtipo;
    private String dir_mail;
    private Integer sycp;

    public Integer getIdalumno() {
        return idalumno;
    }

    public void setIdalumno(Integer idalumno) {
        this.idalumno = idalumno;
    }

    public String getNombreAlumno() {
        return nombreAlumno;
    }

    public void setNombreAlumno(String nombreAlumno) {
        this.nombreAlumno = nombreAlumno;
    }

    public Integer getIde() {
        return ide;
    }

    public void setIde(Integer ide) {
        this.ide = ide;
    }

    public String getRegistrante() {
        return registrante;
    }

    public void setRegistrante(String registrante) {
        this.registrante = registrante;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getCor_user() {
        return cor_user;
    }

    public void setCor_user(String cor_user) {
        this.cor_user = cor_user;
    }

    public String getCor_mail() {
        return cor_mail;
    }

    public void setCor_mail(String cor_mail) {
        this.cor_mail = cor_mail;
    }

    public Date getFecha() {
        return fecha;
    }

    public void setFecha(Date fecha) {
        this.fecha = fecha;
    }

    public Date getHora() {
        return hora;
    }

    public void setHora(Date hora) {
        this.hora = hora;
    }

    public String getLugar() {
        return lugar;
    }

    public void setLugar(String lugar) {
        this.lugar = lugar;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getSubtipo() {
        return subtipo;
    }

    public void setSubtipo(String subtipo) {
        this.subtipo = subtipo;
    }

    public String getDir_mail() {
        return dir_mail;
    }

    public void setDir_mail(String dir_mail) {
        this.dir_mail = dir_mail;
    }

    public Integer getSycp() {
        return sycp;
    }

    public void setSycp(Integer sycp) {
        this.sycp = sycp;
    }

}
