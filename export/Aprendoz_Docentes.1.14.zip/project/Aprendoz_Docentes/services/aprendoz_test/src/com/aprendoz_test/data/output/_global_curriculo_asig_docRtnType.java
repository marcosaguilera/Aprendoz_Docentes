
package com.aprendoz_test.data.output;



/**
 * Generated for query "_global_curriculo_asig_doc" on 07/31/2014 10:31:51
 * 
 */
public class _global_curriculo_asig_docRtnType {

    private Integer idpersona;
    private String nick;
    private Integer idasignatura;
    private String asignatura;
    private String subject;
    private Integer subarea1;
    private Integer subarea2;
    private Integer subarea3;
    private Integer idsy;
    private String year;

    public Integer getIdpersona() {
        return idpersona;
    }

    public void setIdpersona(Integer idpersona) {
        this.idpersona = idpersona;
    }

    public String getNick() {
        return nick;
    }

    public void setNick(String nick) {
        this.nick = nick;
    }

    public Integer getIdasignatura() {
        return idasignatura;
    }

    public void setIdasignatura(Integer idasignatura) {
        this.idasignatura = idasignatura;
    }

    public String getAsignatura() {
        return asignatura;
    }

    public void setAsignatura(String asignatura) {
        this.asignatura = asignatura;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public Integer getSubarea1() {
        return subarea1;
    }

    public void setSubarea1(Integer subarea1) {
        this.subarea1 = subarea1;
    }

    public Integer getSubarea2() {
        return subarea2;
    }

    public void setSubarea2(Integer subarea2) {
        this.subarea2 = subarea2;
    }

    public Integer getSubarea3() {
        return subarea3;
    }

    public void setSubarea3(Integer subarea3) {
        this.subarea3 = subarea3;
    }

    public Integer getIdsy() {
        return idsy;
    }

    public void setIdsy(Integer idsy) {
        this.idsy = idsy;
    }

    public String getYear() {
        return year;
    }

    public void setYear(String year) {
        this.year = year;
    }

}
