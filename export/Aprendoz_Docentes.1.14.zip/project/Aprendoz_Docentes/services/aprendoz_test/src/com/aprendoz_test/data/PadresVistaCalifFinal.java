
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaCalifFinal
 *  07/31/2014 10:31:31
 * 
 */
public class PadresVistaCalifFinal {

    private PadresVistaCalifFinalId id;

    public PadresVistaCalifFinalId getId() {
        return id;
    }

    public void setId(PadresVistaCalifFinalId id) {
        this.id = id;
    }

}
