
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaPersonasPromocion
 *  07/31/2014 10:31:31
 * 
 */
public class PadresVistaPersonasPromocion {

    private PadresVistaPersonasPromocionId id;

    public PadresVistaPersonasPromocionId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasPromocionId id) {
        this.id = id;
    }

}
