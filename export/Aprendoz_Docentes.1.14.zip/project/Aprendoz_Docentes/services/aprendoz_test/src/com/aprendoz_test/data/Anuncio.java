
package com.aprendoz_test.data;



/**
 *  aprendoz_test.Anuncio
 *  07/31/2014 10:31:32
 * 
 */
public class Anuncio {

    private String anuncio;

    public String getAnuncio() {
        return anuncio;
    }

    public void setAnuncio(String anuncio) {
        this.anuncio = anuncio;
    }

}
