
package com.aprendoz_test.data;



/**
 *  aprendoz_test.ImportacionExtracto
 *  01/19/2015 07:58:53
 * 
 */
public class ImportacionExtracto {

    private ImportacionExtractoId id;

    public ImportacionExtractoId getId() {
        return id;
    }

    public void setId(ImportacionExtractoId id) {
        this.id = id;
    }

}
