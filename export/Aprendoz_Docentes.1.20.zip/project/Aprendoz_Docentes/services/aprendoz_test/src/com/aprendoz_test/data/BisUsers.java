
package com.aprendoz_test.data;



/**
 *  aprendoz_test.BisUsers
 *  01/19/2015 07:58:53
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}
