
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaPersonas
 *  01/19/2015 07:58:52
 * 
 */
public class PadresVistaPersonas {

    private PadresVistaPersonasId id;

    public PadresVistaPersonasId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasId id) {
        this.id = id;
    }

}
