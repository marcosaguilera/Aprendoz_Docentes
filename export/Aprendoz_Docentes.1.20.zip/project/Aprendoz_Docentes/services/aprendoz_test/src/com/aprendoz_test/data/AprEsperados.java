
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AprEsperados
 *  01/19/2015 07:58:52
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
