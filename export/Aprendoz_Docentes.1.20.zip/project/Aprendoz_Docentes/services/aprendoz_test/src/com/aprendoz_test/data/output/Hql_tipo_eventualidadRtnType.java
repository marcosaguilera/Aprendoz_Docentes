
package com.aprendoz_test.data.output;



/**
 * Generated for query "hql_tipo_eventualidad" on 01/19/2015 07:59:26
 * 
 */
public class Hql_tipo_eventualidadRtnType {

    private Integer id;
    private String tipo;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

}
