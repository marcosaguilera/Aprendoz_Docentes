
package com.aprendoz_test.data;



/**
 *  aprendoz_test.LimitesCalificaciones
 *  01/19/2015 07:58:53
 * 
 */
public class LimitesCalificaciones {

    private Integer idLimitesCalificaciones;
    private Integer syIdSy;
    private String calificacion;
    private Float valor;

    public Integer getIdLimitesCalificaciones() {
        return idLimitesCalificaciones;
    }

    public void setIdLimitesCalificaciones(Integer idLimitesCalificaciones) {
        this.idLimitesCalificaciones = idLimitesCalificaciones;
    }

    public Integer getSyIdSy() {
        return syIdSy;
    }

    public void setSyIdSy(Integer syIdSy) {
        this.syIdSy = syIdSy;
    }

    public String getCalificacion() {
        return calificacion;
    }

    public void setCalificacion(String calificacion) {
        this.calificacion = calificacion;
    }

    public Float getValor() {
        return valor;
    }

    public void setValor(Float valor) {
        this.valor = valor;
    }

}
