
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresCorreosPadres
 *  01/19/2015 07:58:53
 * 
 */
public class PadresCorreosPadres {

    private PadresCorreosPadresId id;

    public PadresCorreosPadresId getId() {
        return id;
    }

    public void setId(PadresCorreosPadresId id) {
        this.id = id;
    }

}
