
package com.aprendoz_test.data.output;



/**
 * Generated for query "getTipoEventualidadByIdSubTipo" on 01/19/2015 07:59:25
 * 
 */
public class GetTipoEventualidadByIdSubTipoRtnType {

    private Integer id;
    private String subtipo;
    private Integer idTipo;
    private String eventualidad;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getSubtipo() {
        return subtipo;
    }

    public void setSubtipo(String subtipo) {
        this.subtipo = subtipo;
    }

    public Integer getIdTipo() {
        return idTipo;
    }

    public void setIdTipo(Integer idTipo) {
        this.idTipo = idTipo;
    }

    public String getEventualidad() {
        return eventualidad;
    }

    public void setEventualidad(String eventualidad) {
        this.eventualidad = eventualidad;
    }

}
