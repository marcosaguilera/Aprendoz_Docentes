
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesAsistenciaAsistencias
 *  01/19/2015 07:58:53
 * 
 */
public class DocentesAsistenciaAsistencias {

    private DocentesAsistenciaAsistenciasId id;

    public DocentesAsistenciaAsistenciasId getId() {
        return id;
    }

    public void setId(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

}
