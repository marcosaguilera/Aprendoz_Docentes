
package com.aprendoz_test.data.output;



/**
 * Generated for query "hqlPersonaEventualidad" on 01/19/2015 07:59:25
 * 
 */
public class HqlPersonaEventualidadRtnType {

    private String nombrecompleto;
    private Integer idsubtipo;
    private String subtipo;
    private Integer id;
    private Integer ideventualidad;

    public String getNombrecompleto() {
        return nombrecompleto;
    }

    public void setNombrecompleto(String nombrecompleto) {
        this.nombrecompleto = nombrecompleto;
    }

    public Integer getIdsubtipo() {
        return idsubtipo;
    }

    public void setIdsubtipo(Integer idsubtipo) {
        this.idsubtipo = idsubtipo;
    }

    public String getSubtipo() {
        return subtipo;
    }

    public void setSubtipo(String subtipo) {
        this.subtipo = subtipo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getIdeventualidad() {
        return ideventualidad;
    }

    public void setIdeventualidad(Integer ideventualidad) {
        this.ideventualidad = ideventualidad;
    }

}
