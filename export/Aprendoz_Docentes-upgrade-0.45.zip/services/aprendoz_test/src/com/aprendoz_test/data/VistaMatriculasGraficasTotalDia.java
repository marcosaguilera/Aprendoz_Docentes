
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaMatriculasGraficasTotalDia
 *  01/09/2014 09:22:29
 * 
 */
public class VistaMatriculasGraficasTotalDia {

    private VistaMatriculasGraficasTotalDiaId id;

    public VistaMatriculasGraficasTotalDia() {
    }

    public VistaMatriculasGraficasTotalDia(VistaMatriculasGraficasTotalDiaId id) {
        this.id = id;
    }

    public VistaMatriculasGraficasTotalDiaId getId() {
        return id;
    }

    public void setId(VistaMatriculasGraficasTotalDiaId id) {
        this.id = id;
    }

}
