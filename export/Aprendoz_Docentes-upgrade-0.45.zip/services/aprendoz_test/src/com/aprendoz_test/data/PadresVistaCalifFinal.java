
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaCalifFinal
 *  01/09/2014 09:22:27
 * 
 */
public class PadresVistaCalifFinal {

    private PadresVistaCalifFinalId id;

    public PadresVistaCalifFinal() {
    }

    public PadresVistaCalifFinal(PadresVistaCalifFinalId id) {
        this.id = id;
    }

    public PadresVistaCalifFinalId getId() {
        return id;
    }

    public void setId(PadresVistaCalifFinalId id) {
        this.id = id;
    }

}
