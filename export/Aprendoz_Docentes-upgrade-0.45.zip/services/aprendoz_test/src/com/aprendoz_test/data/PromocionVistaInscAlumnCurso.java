
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PromocionVistaInscAlumnCurso
 *  01/09/2014 09:22:28
 * 
 */
public class PromocionVistaInscAlumnCurso {

    private PromocionVistaInscAlumnCursoId id;

    public PromocionVistaInscAlumnCurso() {
    }

    public PromocionVistaInscAlumnCurso(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

    public PromocionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(PromocionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
