
package com.aprendoz_test.data;



/**
 *  aprendoz_test.BisUsers
 *  01/09/2014 09:22:28
 * 
 */
public class BisUsers {

    private BisUsersId id;

    public BisUsers() {
    }

    public BisUsers(BisUsersId id) {
        this.id = id;
    }

    public BisUsersId getId() {
        return id;
    }

    public void setId(BisUsersId id) {
        this.id = id;
    }

}
