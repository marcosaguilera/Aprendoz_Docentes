
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesAsistenciaAsistencias
 *  01/09/2014 09:22:28
 * 
 */
public class DocentesAsistenciaAsistencias {

    private DocentesAsistenciaAsistenciasId id;

    public DocentesAsistenciaAsistencias() {
    }

    public DocentesAsistenciaAsistencias(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

    public DocentesAsistenciaAsistenciasId getId() {
        return id;
    }

    public void setId(DocentesAsistenciaAsistenciasId id) {
        this.id = id;
    }

}
