
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaPadresTransporteRutas
 *  05/27/2013 16:03:55
 * 
 */
public class VistaPadresTransporteRutas {

    private VistaPadresTransporteRutasId id;

    public VistaPadresTransporteRutas() {
    }

    public VistaPadresTransporteRutas(VistaPadresTransporteRutasId id) {
        this.id = id;
    }

    public VistaPadresTransporteRutasId getId() {
        return id;
    }

    public void setId(VistaPadresTransporteRutasId id) {
        this.id = id;
    }

}
