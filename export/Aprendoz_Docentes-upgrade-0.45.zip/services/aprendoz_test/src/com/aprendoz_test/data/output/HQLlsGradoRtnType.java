
package com.aprendoz_test.data.output;



/**
 * Generated for query "hQLlsGrado" on 01/09/2014 11:35:16
 * 
 */
public class HQLlsGradoRtnType {

    private Integer id;
    private String grado;

    public HQLlsGradoRtnType() {
    }

    public HQLlsGradoRtnType(Integer id, String grado) {
        this.id = id;
        this.grado = grado;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

}
