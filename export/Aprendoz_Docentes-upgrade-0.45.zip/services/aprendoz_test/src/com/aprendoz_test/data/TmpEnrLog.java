
package com.aprendoz_test.data;



/**
 *  aprendoz_test.TmpEnrLog
 *  01/09/2014 09:22:29
 * 
 */
public class TmpEnrLog {

    private TmpEnrLogId id;

    public TmpEnrLog() {
    }

    public TmpEnrLog(TmpEnrLogId id) {
        this.id = id;
    }

    public TmpEnrLogId getId() {
        return id;
    }

    public void setId(TmpEnrLogId id) {
        this.id = id;
    }

}
