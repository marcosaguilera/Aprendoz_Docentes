
package com.aprendoz_test.data.output;



/**
 * Generated for query "hQLlsCursos" on 01/09/2014 11:35:15
 * 
 */
public class HQLlsCursosRtnType {

    private Integer id;
    private String curso;

    public HQLlsCursosRtnType() {
    }

    public HQLlsCursosRtnType(Integer id, String curso) {
        this.id = id;
        this.curso = curso;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

}
