
package com.aprendoz_test.data;



/**
 *  aprendoz_test.Vistaasistencia
 *  01/09/2014 09:22:29
 * 
 */
public class Vistaasistencia {

    private VistaasistenciaId id;

    public Vistaasistencia() {
    }

    public Vistaasistencia(VistaasistenciaId id) {
        this.id = id;
    }

    public VistaasistenciaId getId() {
        return id;
    }

    public void setId(VistaasistenciaId id) {
        this.id = id;
    }

}
