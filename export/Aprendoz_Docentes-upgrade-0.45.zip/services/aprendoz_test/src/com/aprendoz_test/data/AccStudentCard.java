
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AccStudentCard
 *  01/09/2014 09:22:29
 * 
 */
public class AccStudentCard {

    private String id;
    private String studentCode;
    private String cardCodeData;
    private String cardNumber;

    public AccStudentCard() {
    }

    public AccStudentCard(String id, String studentCode, String cardCodeData, String cardNumber) {
        this.id = id;
        this.studentCode = studentCode;
        this.cardCodeData = cardCodeData;
        this.cardNumber = cardNumber;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getStudentCode() {
        return studentCode;
    }

    public void setStudentCode(String studentCode) {
        this.studentCode = studentCode;
    }

    public String getCardCodeData() {
        return cardCodeData;
    }

    public void setCardCodeData(String cardCodeData) {
        this.cardCodeData = cardCodeData;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

}
