
package com.aprendoz_test.data.output;



/**
 * Generated for query "hql_tipo_eventualidad" on 01/09/2014 11:35:16
 * 
 */
public class Hql_tipo_eventualidadRtnType {

    private Integer id;
    private String tipo;

    public Hql_tipo_eventualidadRtnType() {
    }

    public Hql_tipo_eventualidadRtnType(Integer id, String tipo) {
        this.id = id;
        this.tipo = tipo;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

}
