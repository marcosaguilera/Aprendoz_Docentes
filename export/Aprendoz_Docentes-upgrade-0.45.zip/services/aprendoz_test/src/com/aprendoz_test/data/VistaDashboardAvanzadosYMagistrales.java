
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaDashboardAvanzadosYMagistrales
 *  01/09/2014 09:22:28
 * 
 */
public class VistaDashboardAvanzadosYMagistrales {

    private VistaDashboardAvanzadosYMagistralesId id;

    public VistaDashboardAvanzadosYMagistrales() {
    }

    public VistaDashboardAvanzadosYMagistrales(VistaDashboardAvanzadosYMagistralesId id) {
        this.id = id;
    }

    public VistaDashboardAvanzadosYMagistralesId getId() {
        return id;
    }

    public void setId(VistaDashboardAvanzadosYMagistralesId id) {
        this.id = id;
    }

}
