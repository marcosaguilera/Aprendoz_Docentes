
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaAsignaturasCurso
 *  01/09/2014 09:22:28
 * 
 */
public class AdministracionVistaAsignaturasCurso {

    private AdministracionVistaAsignaturasCursoId id;

    public AdministracionVistaAsignaturasCurso() {
    }

    public AdministracionVistaAsignaturasCurso(AdministracionVistaAsignaturasCursoId id) {
        this.id = id;
    }

    public AdministracionVistaAsignaturasCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasCursoId id) {
        this.id = id;
    }

}
