
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesInicioVistaDetallesAcceso
 *  01/09/2014 09:22:28
 * 
 */
public class DocentesInicioVistaDetallesAcceso {

    private DocentesInicioVistaDetallesAccesoId id;

    public DocentesInicioVistaDetallesAcceso() {
    }

    public DocentesInicioVistaDetallesAcceso(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

    public DocentesInicioVistaDetallesAccesoId getId() {
        return id;
    }

    public void setId(DocentesInicioVistaDetallesAccesoId id) {
        this.id = id;
    }

}
