
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaCalificacionFinal
 *  01/09/2014 09:22:29
 * 
 */
public class DocentesVistaCalificacionFinal {

    private DocentesVistaCalificacionFinalId id;

    public DocentesVistaCalificacionFinal() {
    }

    public DocentesVistaCalificacionFinal(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

    public DocentesVistaCalificacionFinalId getId() {
        return id;
    }

    public void setId(DocentesVistaCalificacionFinalId id) {
        this.id = id;
    }

}
