
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AprLogrados
 *  01/09/2014 09:22:29
 * 
 */
public class AprLogrados {

    private AprLogradosId id;

    public AprLogrados() {
    }

    public AprLogrados(AprLogradosId id) {
        this.id = id;
    }

    public AprLogradosId getId() {
        return id;
    }

    public void setId(AprLogradosId id) {
        this.id = id;
    }

}
