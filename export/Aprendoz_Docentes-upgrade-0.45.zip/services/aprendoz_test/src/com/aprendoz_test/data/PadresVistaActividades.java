
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaActividades
 *  01/09/2014 09:22:29
 * 
 */
public class PadresVistaActividades {

    private PadresVistaActividadesId id;

    public PadresVistaActividades() {
    }

    public PadresVistaActividades(PadresVistaActividadesId id) {
        this.id = id;
    }

    public PadresVistaActividadesId getId() {
        return id;
    }

    public void setId(PadresVistaActividadesId id) {
        this.id = id;
    }

}
