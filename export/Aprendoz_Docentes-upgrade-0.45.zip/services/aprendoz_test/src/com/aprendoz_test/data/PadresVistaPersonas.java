
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaPersonas
 *  01/09/2014 09:22:28
 * 
 */
public class PadresVistaPersonas {

    private PadresVistaPersonasId id;

    public PadresVistaPersonas() {
    }

    public PadresVistaPersonas(PadresVistaPersonasId id) {
        this.id = id;
    }

    public PadresVistaPersonasId getId() {
        return id;
    }

    public void setId(PadresVistaPersonasId id) {
        this.id = id;
    }

}
