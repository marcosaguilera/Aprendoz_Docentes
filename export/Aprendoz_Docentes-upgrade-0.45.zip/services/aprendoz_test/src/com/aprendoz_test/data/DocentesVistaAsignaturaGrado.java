
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaAsignaturaGrado
 *  01/09/2014 09:22:28
 * 
 */
public class DocentesVistaAsignaturaGrado {

    private DocentesVistaAsignaturaGradoId id;

    public DocentesVistaAsignaturaGrado() {
    }

    public DocentesVistaAsignaturaGrado(DocentesVistaAsignaturaGradoId id) {
        this.id = id;
    }

    public DocentesVistaAsignaturaGradoId getId() {
        return id;
    }

    public void setId(DocentesVistaAsignaturaGradoId id) {
        this.id = id;
    }

}
