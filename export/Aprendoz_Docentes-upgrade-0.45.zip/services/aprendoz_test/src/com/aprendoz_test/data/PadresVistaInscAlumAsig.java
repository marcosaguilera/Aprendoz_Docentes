
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaInscAlumAsig
 *  01/09/2014 09:22:28
 * 
 */
public class PadresVistaInscAlumAsig {

    private PadresVistaInscAlumAsigId id;

    public PadresVistaInscAlumAsig() {
    }

    public PadresVistaInscAlumAsig(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

    public PadresVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

}
