
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaAlumnosActivos
 *  01/09/2014 09:22:27
 * 
 */
public class VistaAlumnosActivos {

    private VistaAlumnosActivosId id;

    public VistaAlumnosActivos() {
    }

    public VistaAlumnosActivos(VistaAlumnosActivosId id) {
        this.id = id;
    }

    public VistaAlumnosActivosId getId() {
        return id;
    }

    public void setId(VistaAlumnosActivosId id) {
        this.id = id;
    }

}
