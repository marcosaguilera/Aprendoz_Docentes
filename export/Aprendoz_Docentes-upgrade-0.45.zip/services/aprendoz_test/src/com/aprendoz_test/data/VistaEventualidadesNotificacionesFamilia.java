
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaEventualidadesNotificacionesFamilia
 *  01/09/2014 09:22:28
 * 
 */
public class VistaEventualidadesNotificacionesFamilia {

    private VistaEventualidadesNotificacionesFamiliaId id;

    public VistaEventualidadesNotificacionesFamilia() {
    }

    public VistaEventualidadesNotificacionesFamilia(VistaEventualidadesNotificacionesFamiliaId id) {
        this.id = id;
    }

    public VistaEventualidadesNotificacionesFamiliaId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesFamiliaId id) {
        this.id = id;
    }

}
