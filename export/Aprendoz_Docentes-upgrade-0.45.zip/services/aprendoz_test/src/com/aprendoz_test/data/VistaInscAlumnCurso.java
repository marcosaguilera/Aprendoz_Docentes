
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaInscAlumnCurso
 *  01/09/2014 09:22:27
 * 
 */
public class VistaInscAlumnCurso {

    private VistaInscAlumnCursoId id;

    public VistaInscAlumnCurso() {
    }

    public VistaInscAlumnCurso(VistaInscAlumnCursoId id) {
        this.id = id;
    }

    public VistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(VistaInscAlumnCursoId id) {
        this.id = id;
    }

}
