
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesInscCursoAsignatura
 *  01/09/2014 09:22:27
 * 
 */
public class DocentesInscCursoAsignatura {

    private DocentesInscCursoAsignaturaId id;

    public DocentesInscCursoAsignatura() {
    }

    public DocentesInscCursoAsignatura(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

    public DocentesInscCursoAsignaturaId getId() {
        return id;
    }

    public void setId(DocentesInscCursoAsignaturaId id) {
        this.id = id;
    }

}
