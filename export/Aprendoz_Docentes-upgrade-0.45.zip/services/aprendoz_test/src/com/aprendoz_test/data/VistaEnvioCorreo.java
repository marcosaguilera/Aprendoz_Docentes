
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaEnvioCorreo
 *  01/09/2014 09:22:29
 * 
 */
public class VistaEnvioCorreo {

    private VistaEnvioCorreoId id;

    public VistaEnvioCorreo() {
    }

    public VistaEnvioCorreo(VistaEnvioCorreoId id) {
        this.id = id;
    }

    public VistaEnvioCorreoId getId() {
        return id;
    }

    public void setId(VistaEnvioCorreoId id) {
        this.id = id;
    }

}
