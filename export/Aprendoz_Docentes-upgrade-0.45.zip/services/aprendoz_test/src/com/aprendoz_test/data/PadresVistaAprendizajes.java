
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaAprendizajes
 *  01/09/2014 09:22:28
 * 
 */
public class PadresVistaAprendizajes {

    private PadresVistaAprendizajesId id;

    public PadresVistaAprendizajes() {
    }

    public PadresVistaAprendizajes(PadresVistaAprendizajesId id) {
        this.id = id;
    }

    public PadresVistaAprendizajesId getId() {
        return id;
    }

    public void setId(PadresVistaAprendizajesId id) {
        this.id = id;
    }

}
