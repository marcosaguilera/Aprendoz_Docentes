
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaInscAlumnAsigDemografica
 *  01/09/2014 09:22:27
 * 
 */
public class DocentesVistaInscAlumnAsigDemografica {

    private DocentesVistaInscAlumnAsigDemograficaId id;

    public DocentesVistaInscAlumnAsigDemografica() {
    }

    public DocentesVistaInscAlumnAsigDemografica(DocentesVistaInscAlumnAsigDemograficaId id) {
        this.id = id;
    }

    public DocentesVistaInscAlumnAsigDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigDemograficaId id) {
        this.id = id;
    }

}
