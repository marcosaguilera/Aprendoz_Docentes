
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaEventualidadesNotificaciones
 *  01/09/2014 09:22:28
 * 
 */
public class VistaEventualidadesNotificaciones {

    private VistaEventualidadesNotificacionesId id;

    public VistaEventualidadesNotificaciones() {
    }

    public VistaEventualidadesNotificaciones(VistaEventualidadesNotificacionesId id) {
        this.id = id;
    }

    public VistaEventualidadesNotificacionesId getId() {
        return id;
    }

    public void setId(VistaEventualidadesNotificacionesId id) {
        this.id = id;
    }

}
