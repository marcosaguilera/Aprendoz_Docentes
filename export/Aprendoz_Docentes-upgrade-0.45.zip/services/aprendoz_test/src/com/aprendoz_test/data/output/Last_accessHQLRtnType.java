
package com.aprendoz_test.data.output;



/**
 * Generated for query "last_accessHQL" on 01/09/2014 11:35:16
 * 
 */
public class Last_accessHQLRtnType {

    private String lastdate;

    public Last_accessHQLRtnType() {
    }

    public Last_accessHQLRtnType(String lastdate) {
        this.lastdate = lastdate;
    }

    public String getLastdate() {
        return lastdate;
    }

    public void setLastdate(String lastdate) {
        this.lastdate = lastdate;
    }

}
