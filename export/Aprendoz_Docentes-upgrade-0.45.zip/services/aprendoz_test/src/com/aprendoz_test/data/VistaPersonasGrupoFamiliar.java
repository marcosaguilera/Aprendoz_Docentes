
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaPersonasGrupoFamiliar
 *  01/09/2014 09:22:27
 * 
 */
public class VistaPersonasGrupoFamiliar {

    private VistaPersonasGrupoFamiliarId id;

    public VistaPersonasGrupoFamiliar() {
    }

    public VistaPersonasGrupoFamiliar(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

    public VistaPersonasGrupoFamiliarId getId() {
        return id;
    }

    public void setId(VistaPersonasGrupoFamiliarId id) {
        this.id = id;
    }

}
