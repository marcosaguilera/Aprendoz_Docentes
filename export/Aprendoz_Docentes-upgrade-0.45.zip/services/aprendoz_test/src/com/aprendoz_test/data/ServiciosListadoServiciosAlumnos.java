
package com.aprendoz_test.data;



/**
 *  aprendoz_test.ServiciosListadoServiciosAlumnos
 *  01/09/2014 09:22:28
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnos() {
    }

    public ServiciosListadoServiciosAlumnos(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}
