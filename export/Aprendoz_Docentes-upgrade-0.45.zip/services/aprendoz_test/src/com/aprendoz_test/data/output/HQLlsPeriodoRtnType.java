
package com.aprendoz_test.data.output;



/**
 * Generated for query "HQLlsPeriodo" on 01/09/2014 11:35:15
 * 
 */
public class HQLlsPeriodoRtnType {

    private Integer id;
    private String periodo;
    private String tipoP;

    public HQLlsPeriodoRtnType() {
    }

    public HQLlsPeriodoRtnType(Integer id, String periodo, String tipoP) {
        this.id = id;
        this.periodo = periodo;
        this.tipoP = tipoP;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getPeriodo() {
        return periodo;
    }

    public void setPeriodo(String periodo) {
        this.periodo = periodo;
    }

    public String getTipoP() {
        return tipoP;
    }

    public void setTipoP(String tipoP) {
        this.tipoP = tipoP;
    }

}
