
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaPersonasDemografica
 *  01/09/2014 09:22:28
 * 
 */
public class DocentesVistaPersonasDemografica {

    private DocentesVistaPersonasDemograficaId id;

    public DocentesVistaPersonasDemografica() {
    }

    public DocentesVistaPersonasDemografica(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

    public DocentesVistaPersonasDemograficaId getId() {
        return id;
    }

    public void setId(DocentesVistaPersonasDemograficaId id) {
        this.id = id;
    }

}
