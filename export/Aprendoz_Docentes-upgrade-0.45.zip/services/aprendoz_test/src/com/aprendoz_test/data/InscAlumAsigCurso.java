
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscAlumAsigCurso
 *  01/09/2014 09:22:28
 * 
 */
public class InscAlumAsigCurso {

    private InscAlumAsigCursoId id;

    public InscAlumAsigCurso() {
    }

    public InscAlumAsigCurso(InscAlumAsigCursoId id) {
        this.id = id;
    }

    public InscAlumAsigCursoId getId() {
        return id;
    }

    public void setId(InscAlumAsigCursoId id) {
        this.id = id;
    }

}
