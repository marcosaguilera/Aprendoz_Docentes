
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VProfesorAsignatura
 *  01/09/2014 09:22:27
 * 
 */
public class VProfesorAsignatura {

    private VProfesorAsignaturaId id;

    public VProfesorAsignatura() {
    }

    public VProfesorAsignatura(VProfesorAsignaturaId id) {
        this.id = id;
    }

    public VProfesorAsignaturaId getId() {
        return id;
    }

    public void setId(VProfesorAsignaturaId id) {
        this.id = id;
    }

}
