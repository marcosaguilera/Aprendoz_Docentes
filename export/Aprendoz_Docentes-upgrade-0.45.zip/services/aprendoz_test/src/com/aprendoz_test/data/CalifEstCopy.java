
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CalifEstCopy
 *  01/09/2014 09:22:28
 * 
 */
public class CalifEstCopy {

    private CalifEstCopyId id;

    public CalifEstCopy() {
    }

    public CalifEstCopy(CalifEstCopyId id) {
        this.id = id;
    }

    public CalifEstCopyId getId() {
        return id;
    }

    public void setId(CalifEstCopyId id) {
        this.id = id;
    }

}
