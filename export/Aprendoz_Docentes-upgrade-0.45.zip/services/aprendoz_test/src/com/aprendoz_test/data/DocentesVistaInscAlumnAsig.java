
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaInscAlumnAsig
 *  01/09/2014 09:22:28
 * 
 */
public class DocentesVistaInscAlumnAsig {

    private DocentesVistaInscAlumnAsigId id;

    public DocentesVistaInscAlumnAsig() {
    }

    public DocentesVistaInscAlumnAsig(DocentesVistaInscAlumnAsigId id) {
        this.id = id;
    }

    public DocentesVistaInscAlumnAsigId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigId id) {
        this.id = id;
    }

}
