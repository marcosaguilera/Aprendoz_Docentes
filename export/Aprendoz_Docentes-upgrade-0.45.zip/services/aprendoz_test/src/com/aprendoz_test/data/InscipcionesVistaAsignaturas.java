
package com.aprendoz_test.data;



/**
 *  aprendoz_test.InscipcionesVistaAsignaturas
 *  01/09/2014 09:22:29
 * 
 */
public class InscipcionesVistaAsignaturas {

    private InscipcionesVistaAsignaturasId id;

    public InscipcionesVistaAsignaturas() {
    }

    public InscipcionesVistaAsignaturas(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

    public InscipcionesVistaAsignaturasId getId() {
        return id;
    }

    public void setId(InscipcionesVistaAsignaturasId id) {
        this.id = id;
    }

}
