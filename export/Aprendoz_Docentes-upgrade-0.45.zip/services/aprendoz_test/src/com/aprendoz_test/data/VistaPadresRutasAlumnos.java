
package com.aprendoz_test.data;



/**
 *  aprendoz_test.VistaPadresRutasAlumnos
 *  05/27/2013 16:03:55
 * 
 */
public class VistaPadresRutasAlumnos {

    private VistaPadresRutasAlumnosId id;

    public VistaPadresRutasAlumnos() {
    }

    public VistaPadresRutasAlumnos(VistaPadresRutasAlumnosId id) {
        this.id = id;
    }

    public VistaPadresRutasAlumnosId getId() {
        return id;
    }

    public void setId(VistaPadresRutasAlumnosId id) {
        this.id = id;
    }

}
