
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AprEsperados
 *  01/09/2014 09:22:28
 * 
 */
public class AprEsperados {

    private AprEsperadosId id;

    public AprEsperados() {
    }

    public AprEsperados(AprEsperadosId id) {
        this.id = id;
    }

    public AprEsperadosId getId() {
        return id;
    }

    public void setId(AprEsperadosId id) {
        this.id = id;
    }

}
