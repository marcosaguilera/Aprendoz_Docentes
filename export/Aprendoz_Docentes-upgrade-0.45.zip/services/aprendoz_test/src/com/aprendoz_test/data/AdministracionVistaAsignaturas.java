
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaAsignaturas
 *  01/09/2014 09:22:28
 * 
 */
public class AdministracionVistaAsignaturas {

    private AdministracionVistaAsignaturasId id;

    public AdministracionVistaAsignaturas() {
    }

    public AdministracionVistaAsignaturas(AdministracionVistaAsignaturasId id) {
        this.id = id;
    }

    public AdministracionVistaAsignaturasId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasId id) {
        this.id = id;
    }

}
