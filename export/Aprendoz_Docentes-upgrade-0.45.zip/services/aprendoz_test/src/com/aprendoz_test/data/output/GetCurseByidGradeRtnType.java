
package com.aprendoz_test.data.output;



/**
 * Generated for query "getCurseByidGrade" on 01/09/2014 11:35:16
 * 
 */
public class GetCurseByidGradeRtnType {

    private Integer idcurso;
    private String curso;
    private Integer idgrado;
    private String grado;

    public GetCurseByidGradeRtnType() {
    }

    public GetCurseByidGradeRtnType(Integer idcurso, String curso, Integer idgrado, String grado) {
        this.idcurso = idcurso;
        this.curso = curso;
        this.idgrado = idgrado;
        this.grado = grado;
    }

    public Integer getIdcurso() {
        return idcurso;
    }

    public void setIdcurso(Integer idcurso) {
        this.idcurso = idcurso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public Integer getIdgrado() {
        return idgrado;
    }

    public void setIdgrado(Integer idgrado) {
        this.idgrado = idgrado;
    }

    public String getGrado() {
        return grado;
    }

    public void setGrado(String grado) {
        this.grado = grado;
    }

}
