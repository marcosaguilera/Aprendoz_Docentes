
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaAsignaturas
 *  01/19/2015 07:58:53
 * 
 */
public class AdministracionVistaAsignaturas {

    private AdministracionVistaAsignaturasId id;

    public AdministracionVistaAsignaturasId getId() {
        return id;
    }

    public void setId(AdministracionVistaAsignaturasId id) {
        this.id = id;
    }

}
