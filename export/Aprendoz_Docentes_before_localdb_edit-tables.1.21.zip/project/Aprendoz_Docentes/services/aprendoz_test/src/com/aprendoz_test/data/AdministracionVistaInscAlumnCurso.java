
package com.aprendoz_test.data;



/**
 *  aprendoz_test.AdministracionVistaInscAlumnCurso
 *  01/19/2015 07:58:53
 * 
 */
public class AdministracionVistaInscAlumnCurso {

    private AdministracionVistaInscAlumnCursoId id;

    public AdministracionVistaInscAlumnCursoId getId() {
        return id;
    }

    public void setId(AdministracionVistaInscAlumnCursoId id) {
        this.id = id;
    }

}
