
package com.aprendoz_test.data;



/**
 *  aprendoz_test.Tarjetasdav050814
 *  01/19/2015 07:58:53
 * 
 */
public class Tarjetasdav050814 {

    private String ncodigo;
    private String nnombre;
    private String numidres;
    private String nombres;
    private String tarjedav;

    public String getNcodigo() {
        return ncodigo;
    }

    public void setNcodigo(String ncodigo) {
        this.ncodigo = ncodigo;
    }

    public String getNnombre() {
        return nnombre;
    }

    public void setNnombre(String nnombre) {
        this.nnombre = nnombre;
    }

    public String getNumidres() {
        return numidres;
    }

    public void setNumidres(String numidres) {
        this.numidres = numidres;
    }

    public String getNombres() {
        return nombres;
    }

    public void setNombres(String nombres) {
        this.nombres = nombres;
    }

    public String getTarjedav() {
        return tarjedav;
    }

    public void setTarjedav(String tarjedav) {
        this.tarjedav = tarjedav;
    }

}
