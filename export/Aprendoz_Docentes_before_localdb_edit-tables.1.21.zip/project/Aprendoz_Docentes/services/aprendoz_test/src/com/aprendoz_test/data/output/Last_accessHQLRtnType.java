
package com.aprendoz_test.data.output;

import java.util.Date;


/**
 * Generated for query "last_accessHQL" on 01/19/2015 07:59:26
 * 
 */
public class Last_accessHQLRtnType {

    private String date;
    private Date timeLoged;

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public Date getTimeLoged() {
        return timeLoged;
    }

    public void setTimeLoged(Date timeLoged) {
        this.timeLoged = timeLoged;
    }

}
