
package com.aprendoz_test.data.output;



/**
 * Generated for query "HQLlsCursos" on 01/19/2015 07:59:25
 * 
 */
public class HQLlsCursosRtnType {

    private Integer id;
    private String curso;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

}
