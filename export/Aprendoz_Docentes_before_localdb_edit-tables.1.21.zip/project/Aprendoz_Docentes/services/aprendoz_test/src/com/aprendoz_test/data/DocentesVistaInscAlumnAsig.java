
package com.aprendoz_test.data;



/**
 *  aprendoz_test.DocentesVistaInscAlumnAsig
 *  01/19/2015 07:58:52
 * 
 */
public class DocentesVistaInscAlumnAsig {

    private DocentesVistaInscAlumnAsigId id;

    public DocentesVistaInscAlumnAsigId getId() {
        return id;
    }

    public void setId(DocentesVistaInscAlumnAsigId id) {
        this.id = id;
    }

}
