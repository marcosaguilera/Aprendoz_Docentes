
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CalifEst
 *  01/19/2015 07:58:53
 * 
 */
public class CalifEst {

    private CalifEstId id;

    public CalifEstId getId() {
        return id;
    }

    public void setId(CalifEstId id) {
        this.id = id;
    }

}
