
package com.aprendoz_test.data;



/**
 *  aprendoz_test.CurriculoGrado
 *  01/19/2015 07:58:53
 * 
 */
public class CurriculoGrado {

    private CurriculoGradoId id;

    public CurriculoGradoId getId() {
        return id;
    }

    public void setId(CurriculoGradoId id) {
        this.id = id;
    }

}
