
package com.aprendoz_test.data;



/**
 *  aprendoz_test.PadresVistaInscAlumAsig
 *  01/19/2015 07:58:53
 * 
 */
public class PadresVistaInscAlumAsig {

    private PadresVistaInscAlumAsigId id;

    public PadresVistaInscAlumAsigId getId() {
        return id;
    }

    public void setId(PadresVistaInscAlumAsigId id) {
        this.id = id;
    }

}
