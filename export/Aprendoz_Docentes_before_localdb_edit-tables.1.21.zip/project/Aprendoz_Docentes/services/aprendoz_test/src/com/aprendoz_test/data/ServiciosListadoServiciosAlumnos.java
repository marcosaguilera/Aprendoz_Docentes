
package com.aprendoz_test.data;



/**
 *  aprendoz_test.ServiciosListadoServiciosAlumnos
 *  01/19/2015 07:58:53
 * 
 */
public class ServiciosListadoServiciosAlumnos {

    private ServiciosListadoServiciosAlumnosId id;

    public ServiciosListadoServiciosAlumnosId getId() {
        return id;
    }

    public void setId(ServiciosListadoServiciosAlumnosId id) {
        this.id = id;
    }

}
