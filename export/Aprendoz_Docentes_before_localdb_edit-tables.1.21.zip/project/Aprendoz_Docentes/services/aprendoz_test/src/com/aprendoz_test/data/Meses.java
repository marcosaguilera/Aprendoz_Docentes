
package com.aprendoz_test.data;



/**
 *  aprendoz_test.Meses
 *  01/19/2015 07:58:52
 * 
 */
public class Meses {

    private Integer id;
    private String mes;
    private String mesnumero;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMes() {
        return mes;
    }

    public void setMes(String mes) {
        this.mes = mes;
    }

    public String getMesnumero() {
        return mesnumero;
    }

    public void setMesnumero(String mesnumero) {
        this.mesnumero = mesnumero;
    }

}
